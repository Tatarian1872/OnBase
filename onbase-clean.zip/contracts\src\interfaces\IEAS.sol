// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

/**
 * @dev EAS Attestation yapısının Solidity temsilcisi.
 */
struct Attestation {
    bytes32 uid;              // Attestation'ın benzersiz kimliği
    bytes32 schema;           // Kullanılan şemanın UID'si
    uint64 time;              // Attestation oluşturulma zaman damgası
    uint64 expirationTime;    // Son geçerlilik tarihi (0 ise sınırsız)
    uint64 revocationTime;    // İptal edilme tarihi (0 ise iptal edilmemiş)
    bytes32 refUID;           // Varsa ilişkili olduğu diğer attestation UID'si
    address recipient;        // Attestation'ın alıcısı
    address attester;         // Attestation'ı oluşturan adres (bizim kontratımız)
    bool revocable;           // İptal edilebilir olup olmadığı
    bytes data;               // ABI ile kodlanmış şema verileri
}

/**
 * @dev EAS'ye attestation talebi gönderirken kullanılan veri yapısı.
 */
struct AttestationRequestData {
    address recipient;        // Attestation'ın verileceği adres
    uint64 expirationTime;    // Son geçerlilik tarihi
    bool revocable;           // İptal edilebilir mi?
    bytes32 refUID;           // Referans attestation UID'si (varsa)
    bytes data;               // Şemaya göre encode edilmiş ham veri
    uint256 value;            // Çözümleyiciye (resolver) gönderilecek ETH tutarı (varsa)
}

/**
 * @dev EAS attest fonksiyonuna geçilen ana istek yapısı.
 */
struct AttestationRequest {
    bytes32 schema;           // Şema UID'si
    AttestationRequestData data; // İstek verisi
}

/**
 * @dev Ethereum Attestation Service (EAS) ana kontrat arayüzü.
 */
interface IEAS {
    /**
     * @notice Yeni bir on-chain attestation (varlık kanıtı) oluşturur.
     * @param request Attestation istek detayları.
     * @return Oluşturulan attestation'ın benzersiz UID'si.
     */
    function attest(AttestationRequest calldata request) external payable returns (bytes32);

    /**
     * @notice Belirli bir UID'ye sahip attestation detayını sorgular.
     */
    function getAttestation(bytes32 uid) external view returns (Attestation memory);

    /**
     * @notice Bir attestation'ın geçerli (var ve iptal edilmemiş) olup olmadığını doğrular.
     */
    function isAttestationValid(bytes32 uid) external view returns (bool);
}
