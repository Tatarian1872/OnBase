// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import { IEAS, Attestation, AttestationRequest } from "../../src/interfaces/IEAS.sol";

/**
 * @title MockEAS
 * @dev Test ortamında EAS (Ethereum Attestation Service) kontratını simüle etmek için mock sınıfı.
 */
contract MockEAS is IEAS {
    mapping(bytes32 => Attestation) private _attestations;
    uint256 private _uidCounter;

    function attest(AttestationRequest calldata request) external payable override returns (bytes32) {
        _uidCounter++;
        bytes32 uid = keccak256(abi.encodePacked(_uidCounter, request.schema, msg.sender, request.data.recipient));
        
        _attestations[uid] = Attestation({
            uid: uid,
            schema: request.schema,
            time: uint64(block.timestamp),
            expirationTime: request.data.expirationTime,
            revocationTime: 0,
            refUID: request.data.refUID,
            recipient: request.data.recipient,
            attester: msg.sender,
            revocable: request.data.revocable,
            data: request.data.data
        });
        
        return uid;
    }

    function getAttestation(bytes32 uid) external view override returns (Attestation memory) {
        return _attestations[uid];
    }

    function isAttestationValid(bytes32 uid) external view override returns (bool) {
        return _attestations[uid].uid != bytes32(0) && _attestations[uid].revocationTime == 0;
    }
}
