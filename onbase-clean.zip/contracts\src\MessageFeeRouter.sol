// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import { IERC20 } from "./interfaces/IERC20.sol";

/**
 * @title MessageFeeRouter
 * @dev Kullanıcıların ilk mesaj gönderiminde USDC ile ücret ödemesini sağlar.
 * Bu ücretler doğrudan bu kontratta (ortak havuzda) biriktirilir.
 * Belirli periyotlarla en aktif 3 kullanıcı arasında dağıtılır.
 */
contract MessageFeeRouter {
    // --- Durum Değişkenleri (State Variables) ---
    
    address public owner;
    IERC20 public immutable usdcToken;
    address public platformAddress; // Gerekirse ek kontroller için saklandı
    
    uint256 public firstMessageFee; // USDC cinsinden ilk mesaj ücreti (varsayılan: 0.01 USDC = 10,000)
    
    // Kullanıcı => Toplam Aktivite Puanı (Gönderilen paid ilk mesaj sayısı)
    mapping(address => uint256) public usageCount;

    // Gönderici => Alıcı => İlk mesaj ödemesi yapıldı mı?
    mapping(address => mapping(address => bool)) public hasPaidFirstMessage;

    // --- Olaylar (Events) ---
    
    event FirstMessagePaid(
        address indexed sender,
        address indexed recipient,
        bytes32 indexed venueHash,
        uint256 feePaid,
        uint256 newUsageCount
    );
    
    event PoolDistributed(
        address[3] topUsers,
        uint256 amountDistributed
    );
    
    event FeeConfigUpdated(uint256 newFee);
    event PlatformAddressUpdated(address oldPlatform, address newPlatform);

    // --- Değiştiriciler (Modifiers) ---
    
    modifier onlyOwner() {
        require(msg.sender == owner, "Yetkisiz: Sadece sahip");
        _;
    }

    // --- Yapıcı (Constructor) ---
    
    constructor(
        address _usdcToken,
        address _platformAddress,
        uint256 _firstMessageFee
    ) {
        require(_usdcToken != address(0), "Gecersiz USDC adresi");
        require(_platformAddress != address(0), "Gecersiz platform adresi");
        
        owner = msg.sender;
        usdcToken = IERC20(_usdcToken);
        platformAddress = _platformAddress;
        firstMessageFee = _firstMessageFee; // Örn. 10000 (0.01 USDC)
    }

    // --- Ana Fonksiyonlar (External Functions) ---

    /**
     * @notice İki kullanıcı arasındaki ilk mesajlaşma ücretini (0.01 USDC) tahsil eder ve havuzda saklar.
     * @param recipient Mesajın gönderileceği alıcı adresi.
     * @param venueHash Mesajın atıldığı bölgenin/mekanın hash'i.
     * @param venueOwner Opsiyonel parametre (Önceki uyumluluk için arayüzde bırakıldı, havuzda kullanılmaz).
     */
    function payFirstMessage(
        address recipient,
        bytes32 venueHash,
        address venueOwner
    ) external {
        require(recipient != address(0), "Gecersiz alici adresi");
        require(recipient != msg.sender, "Kendinize mesaj ucreti odeyemezsiniz");
        require(!hasPaidFirstMessage[msg.sender][recipient], "Ilk mesaj ucreti zaten odendi");

        // 1. Durumu güncelle (Reentrancy koruması için transferden önce)
        hasPaidFirstMessage[msg.sender][recipient] = true;
        usageCount[msg.sender]++;

        // 2. Ücreti havuzda biriktirmek üzere kontratın kendisine transfer et
        if (firstMessageFee > 0) {
            bool success = usdcToken.transferFrom(msg.sender, address(this), firstMessageFee);
            require(success, "USDC havuz transferi basarisiz");
        }

        emit FirstMessagePaid(msg.sender, recipient, venueHash, firstMessageFee, usageCount[msg.sender]);
    }

    /**
     * @notice Havuzda biriken tüm USDC bakiyesini en aktif 3 kullanıcıya dağıtır (%50, %30, %20).
     * @param topUsers En çok kullanan 3 kullanıcının cüzdan adresleri sırasıyla [1. Sıra, 2. Sıra, 3. Sıra].
     */
    function distributePool(address[3] calldata topUsers) external onlyOwner {
        uint256 totalBalance = usdcToken.balanceOf(address(this));
        require(totalBalance > 0, "Havuzda biriken bakiye yok");

        // Payları hesapla (%50, %30, %20)
        uint256 firstShare = (totalBalance * 50) / 100;
        uint256 secondShare = (totalBalance * 30) / 100;
        uint256 thirdShare = totalBalance - firstShare - secondShare; // Yuvarlama kaybını önlemek için kalan pay

        // Transferleri gerçekleştir
        if (topUsers[0] != address(0) && firstShare > 0) {
            bool success = usdcToken.transfer(topUsers[0], firstShare);
            require(success, "1.lik odulu transferi basarisiz");
        }
        if (topUsers[1] != address(0) && secondShare > 0) {
            bool success = usdcToken.transfer(topUsers[1], secondShare);
            require(success, "2.lik odulu transferi basarisiz");
        }
        if (topUsers[2] != address(0) && thirdShare > 0) {
            bool success = usdcToken.transfer(topUsers[2], thirdShare);
            require(success, "3.luk odulu transferi basarisiz");
        }

        emit PoolDistributed(topUsers, totalBalance);
    }

    /**
     * @notice İki kullanıcı arasındaki ilk mesaj ödemesi yapıldı mı sorgular.
     */
    function hasPaid(address sender, address recipient) external view returns (bool) {
        return hasPaidFirstMessage[sender][recipient];
    }

    /**
     * @notice Biriken toplam havuz büyüklüğünü USDC cinsinden sorgular.
     */
    function getPoolBalance() external view returns (uint256) {
        return usdcToken.balanceOf(address(this));
    }

    // --- Yönetici Fonksiyonları (Owner Functions) ---

    function setFirstMessageFee(uint256 _newFee) external onlyOwner {
        firstMessageFee = _newFee;
        emit FeeConfigUpdated(_newFee);
    }

    function setPlatformAddress(address _newPlatformAddress) external onlyOwner {
        require(_newPlatformAddress != address(0), "Gecersiz platform adresi");
        emit PlatformAddressUpdated(platformAddress, _newPlatformAddress);
        platformAddress = _newPlatformAddress;
    }

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "Gecersiz yeni sahip");
        owner = newOwner;
    }
}
