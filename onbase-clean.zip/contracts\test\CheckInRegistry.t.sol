// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

// Foundry standart test kütüphanesi
import { Test } from "forge-std/Test.sol";
import { CheckInRegistry } from "../src/CheckInRegistry.sol";
import { MessageFeeRouter } from "../src/MessageFeeRouter.sol";
import { ChatPhotoNFT } from "../src/ChatPhotoNFT.sol";
import { MockUSDC } from "./mocks/MockUSDC.sol";
import { MockEAS } from "./mocks/MockEAS.sol";

contract CheckInRegistryTest is Test {
    CheckInRegistry public registry;
    MessageFeeRouter public messageRouter;
    ChatPhotoNFT public photoNFT;
    MockUSDC public usdc;
    MockEAS public eas;

    // Test adresleri ve private key'ler
    uint256 public validatorPrivateKey = 0x1111;
    address public validator;
    
    address public user = address(0x2222);
    address public recipient = address(0x3333);
    address public platform = address(0x4444);
    address public venueOwner = address(0x5555);

    bytes32 public constant VENUE_HASH = keccak256("Kadıköy_Bira_Fabrikasi");
    bytes32 public constant EAS_SCHEMA = keccak256("CheckInSchema(bytes32 venueHash,uint64 timestamp)");
    uint256 public constant CHECK_IN_FEE = 100000; // 0.1 USDC
    uint256 public constant MESSAGE_FEE = 10000; // 0.01 USDC

    function setUp() public {
        validator = vm.addr(validatorPrivateKey);
        
        // 1. Mock kontratları deploy et
        usdc = new MockUSDC();
        eas = new MockEAS();

        // 2. CheckInRegistry deploy et
        registry = new CheckInRegistry(
            address(usdc),
            address(eas),
            EAS_SCHEMA,
            validator,
            CHECK_IN_FEE
        );

        // 3. ChatPhotoNFT deploy et
        photoNFT = new ChatPhotoNFT();

        // 4. MessageFeeRouter deploy et
        messageRouter = new MessageFeeRouter(
            address(usdc),
            platform,
            MESSAGE_FEE
        );

        // Test cüzdanını fonla
        usdc.mint(user, 10 * 10**6); // 10 USDC
    }

    // --- İmza Oluşturma Yardımcısı ---
    function _generateSignature(
        address userAddr,
        bytes32 venue,
        uint256 expirationTime,
        uint256 key
    ) internal pure returns (bytes memory) {
        bytes32 messageHash = keccak256(abi.encodePacked(userAddr, venue, expirationTime));
        bytes32 ethSignedMessageHash = keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", messageHash));
        
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(key, ethSignedMessageHash);
        return abi.encodePacked(r, s, v);
    }

    // --- CheckInRegistry Testleri ---

    function test_HappyPathCheckIn() public {
        uint64 duration = 3 hours;
        uint256 sigExpiration = block.timestamp + 10 minutes;
        
        bytes memory sig = _generateSignature(user, VENUE_HASH, sigExpiration, validatorPrivateKey);

        // Kullanıcı olarak USDC onayı ver
        vm.startPrank(user);
        usdc.approve(address(registry), CHECK_IN_FEE);
        
        // Check-in gerçekleştir
        registry.checkIn(VENUE_HASH, duration, sigExpiration, sig);
        vm.stopPrank();

        // Doğrulamalar
        // 1. Cüzdandan USDC çekildi mi?
        assertEq(usdc.balanceOf(user), 10 * 10**6 - CHECK_IN_FEE);
        assertEq(usdc.balanceOf(address(registry)), CHECK_IN_FEE);

        // 2. Check-in kaydı doğru oluşturuldu mu?
        CheckInRegistry.CheckIn memory active = registry.getActiveCheckIn(user);
        assertEq(active.venueHash, VENUE_HASH);
        assertEq(active.expiry, block.timestamp + duration);
        assertTrue(active.attestationUid != bytes32(0));

        // 3. Durum aktif mi?
        assertTrue(registry.isCheckInActive(user, VENUE_HASH));
    }

    function test_RevertIfExpiredSignature() public {
        uint64 duration = 3 hours;
        uint256 sigExpiration = block.timestamp + 10 minutes;
        bytes memory sig = _generateSignature(user, VENUE_HASH, sigExpiration, validatorPrivateKey);

        // Zamanı imza süresinin ötesine al
        vm.warp(sigExpiration + 1 seconds);

        vm.startPrank(user);
        usdc.approve(address(registry), CHECK_IN_FEE);
        
        // Revert etmesi gerekir
        vm.expectRevert("Validator imzasi zaman asimina ugradi");
        registry.checkIn(VENUE_HASH, duration, sigExpiration, sig);
        vm.stopPrank();
    }

    function test_RevertIfInvalidSignature() public {
        uint64 duration = 3 hours;
        uint256 sigExpiration = block.timestamp + 10 minutes;
        
        // Yetkisiz bir key ile imza oluştur (0x9999)
        bytes memory badSig = _generateSignature(user, VENUE_HASH, sigExpiration, 0x9999);

        vm.startPrank(user);
        usdc.approve(address(registry), CHECK_IN_FEE);
        
        vm.expectRevert("Gecersiz GPS imzasi: Yetkisiz validator");
        registry.checkIn(VENUE_HASH, duration, sigExpiration, badSig);
        vm.stopPrank();
    }

    function test_RevertIfInsufficientUSDC() public {
        uint64 duration = 3 hours;
        uint256 sigExpiration = block.timestamp + 10 minutes;
        bytes memory sig = _generateSignature(user, VENUE_HASH, sigExpiration, validatorPrivateKey);

        // USDC onayı (approve) verilmedi
        vm.startPrank(user);
        
        vm.expectRevert("USDC transferi basarisiz");
        registry.checkIn(VENUE_HASH, duration, sigExpiration, sig);
        vm.stopPrank();
    }

    function test_DoubleCheckInUpdatesState() public {
        uint64 duration = 3 hours;
        uint256 sigExpiration = block.timestamp + 10 minutes;
        
        bytes memory sig1 = _generateSignature(user, VENUE_HASH, sigExpiration, validatorPrivateKey);

        vm.startPrank(user);
        usdc.approve(address(registry), CHECK_IN_FEE * 2);
        registry.checkIn(VENUE_HASH, duration, sigExpiration, sig1);
        
        // Mekan 1 aktif
        assertEq(registry.getActiveCheckIn(user).venueHash, VENUE_HASH);

        // İkinci check-in için farklı mekan
        bytes32 otherVenue = keccak256("Kadikoy_Barlar_Sokagi");
        bytes memory sig2 = _generateSignature(user, otherVenue, sigExpiration, validatorPrivateKey);

        registry.checkIn(otherVenue, duration, sigExpiration, sig2);
        vm.stopPrank();

        // Yeni mekanın üzerine yazılması doğrulanır
        assertEq(registry.getActiveCheckIn(user).venueHash, otherVenue);
    }

    // --- MessageFeeRouter Testleri ---

    function test_MessageFeeRouterHappyPath() public {
        vm.startPrank(user);
        usdc.approve(address(messageRouter), MESSAGE_FEE);
        
        messageRouter.payFirstMessage(recipient, VENUE_HASH, venueOwner);
        vm.stopPrank();

        // Ücret havuzda (kontratta) birikmeli
        assertEq(usdc.balanceOf(address(messageRouter)), MESSAGE_FEE);
        assertEq(messageRouter.getPoolBalance(), MESSAGE_FEE);
        
        // Aktivite puanı artmalı
        assertEq(messageRouter.usageCount(user), 1);
        
        // Gönderici bakiyesi azalmalı
        assertEq(usdc.balanceOf(user), 10 * 10**6 - MESSAGE_FEE);

        // Durum güncellendi mi?
        assertTrue(messageRouter.hasPaid(user, recipient));
    }

    function test_PoolDistribution() public {
        // Havuzda bir miktar bakiye biriktirelim
        vm.startPrank(user);
        usdc.approve(address(messageRouter), MESSAGE_FEE);
        messageRouter.payFirstMessage(recipient, VENUE_HASH, venueOwner);
        vm.stopPrank();

        uint256 poolSize = messageRouter.getPoolBalance();
        assertEq(poolSize, MESSAGE_FEE);

        // En aktif 3 kullanıcı
        address user1 = address(0x91);
        address user2 = address(0x92);
        address user3 = address(0x93);
        address[3] memory topUsers = [user1, user2, user3];

        // Dağıtım yap (Owner olarak çağrılır)
        messageRouter.distributePool(topUsers);

        // %50, %30, %20 oranları
        assertEq(usdc.balanceOf(user1), (poolSize * 50) / 100);
        assertEq(usdc.balanceOf(user2), (poolSize * 30) / 100);
        assertEq(usdc.balanceOf(user3), poolSize - (poolSize * 50) / 100 - (poolSize * 30) / 100);

        // Havuz boşalmalı
        assertEq(messageRouter.getPoolBalance(), 0);
    }

    function test_RevertPoolDistributionIfNonOwner() public {
        address[3] memory topUsers = [address(0x91), address(0x92), address(0x93)];
        
        // Yetkisiz kullanıcı olarak çağrıldığında revert etmeli
        vm.prank(user);
        vm.expectRevert("Yetkisiz: Sadece sahip");
        messageRouter.distributePool(topUsers);
    }

    // --- ChatPhotoNFT Testleri ---

    function test_HappyPathChatPhotoNFTMint() public {
        string memory tokenUri = "ipfs://QmDummyHash/photo.json";

        vm.prank(user);
        uint256 tokenId = photoNFT.mint(recipient, tokenUri);

        // Doğrulamalar
        assertEq(tokenId, 0); // İlk basılan NFT ID'si 0 olmalı
        assertEq(photoNFT.ownerOf(tokenId), recipient);
        assertEq(photoNFT.balanceOf(recipient), 1);
        assertEq(photoNFT.tokenURI(tokenId), tokenUri);
    }

    function test_RevertIfNFTMintWithEmptyUri() public {
        vm.prank(user);
        vm.expectRevert("Gecersiz metadata URI");
        photoNFT.mint(recipient, "");
    }

    function test_RevertIfNFTMintToZeroAddress() public {
        string memory tokenUri = "ipfs://QmDummyHash/photo.json";

        vm.prank(user);
        vm.expectRevert("Gecersiz alici adresi");
        photoNFT.mint(address(0), tokenUri);
    }
}
