// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

/**
 * @title ChatPhotoNFT
 * @dev Kullanıcıların sohbet içinde birbirlerine yolladıkları fotoğrafları 
 * temsil eden ve doğrudan alıcının cüzdanına basılan (mint) basit ve gaz-dostu 
 * bir ERC-721 (NFT) akıllı sözleşmesi.
 */
contract ChatPhotoNFT {
    // --- State Variables ---
    
    string public name = "Buradayim Chat Photo NFT";
    string public symbol = "BCPNFT";
    
    uint256 public nextTokenId;
    address public owner;
    
    // Token ID => Sahip Adresi
    mapping(uint256 => address) private _owners;
    
    // Sahip Adresi => Sahip Olunan Token Miktarı
    mapping(address => uint256) private _balances;
    
    // Token ID => Metadata URI (Resim ve diğer bilgiler)
    mapping(uint256 => string) private _tokenURIs;

    // --- Events ---
    
    event Transfer(address indexed from, address indexed to, uint256 indexed tokenId);
    
    event NFTMinted(
        uint256 indexed tokenId, 
        address indexed sender, 
        address indexed recipient, 
        string tokenURI
    );

    // --- Constructor ---
    
    constructor() {
        owner = msg.sender;
    }

    // --- External Functions ---

    /**
     * @notice Yeni bir sohbet fotoğrafını alıcı adrese NFT olarak basar (mint).
     * @param recipient NFT'nin gönderileceği alıcı cüzdan adresi.
     * @param uri NFT'nin metadata JSON adresi (resim url, gönderen vb. içerir).
     * @return tokenId Basılan NFT'nin benzersiz numarası.
     */
    function mint(address recipient, string calldata uri) external returns (uint256) {
        require(recipient != address(0), "Gecersiz alici adresi");
        require(bytes(uri).length > 0, "Gecersiz metadata URI");

        uint256 tokenId = nextTokenId;
        nextTokenId++;

        // Sahiplik ataması
        _owners[tokenId] = recipient;
        _balances[recipient]++;
        _tokenURIs[tokenId] = uri;

        emit Transfer(address(0), recipient, tokenId);
        emit NFTMinted(tokenId, msg.sender, recipient, uri);

        return tokenId;
    }

    // --- View Functions ---

    /**
     * @notice Belirli bir token ID'sinin sahibini sorgular.
     */
    function ownerOf(uint256 tokenId) external view returns (address) {
        address tokenOwner = _owners[tokenId];
        require(tokenOwner != address(0), "Gecersiz token ID");
        return tokenOwner;
    }

    /**
     * @notice Bir cüzdanın sahip olduğu NFT sayısını sorgular.
     */
    function balanceOf(address user) external view returns (uint256) {
        require(user != address(0), "Gecersiz adres");
        return _balances[user];
    }

    /**
     * @notice NFT'nin metadata adresini döner.
     */
    function tokenURI(uint256 tokenId) external view returns (string memory) {
        require(_owners[tokenId] != address(0), "Gecersiz token ID");
        return _tokenURIs[tokenId];
    }
}
