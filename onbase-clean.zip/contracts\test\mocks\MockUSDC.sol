// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import { IERC20 } from "../../src/interfaces/IERC20.sol";

/**
 * @title MockUSDC
 * @dev Test ortamında kullanmak üzere basit bir USDC mock tokenı.
 */
contract MockUSDC is IERC20 {
    string public constant name = "USD Coin (Mock)";
    string public constant symbol = "USDC";
    uint8 public constant decimals = 6;

    uint256 private _totalSupply;
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;

    function totalSupply() external view override returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) external view override returns (uint256) {
        return _balances[account];
    }

    function transfer(address to, uint256 value) external override returns (bool) {
        require(to != address(0), "Gecersiz alici");
        require(_balances[msg.sender] >= value, "Yetersiz bakiye");

        _balances[msg.sender] -= value;
        _balances[to] += value;
        emit Transfer(msg.sender, to, value);
        return true;
    }

    function allowance(address owner, address spender) external view override returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(address spender, uint256 value) external override returns (bool) {
        _allowances[msg.sender][spender] = value;
        emit Approval(msg.sender, spender, value);
        return true;
    }

    function transferFrom(address from, address to, uint256 value) external override returns (bool) {
        require(from != address(0), "Gecersiz gonderici");
        require(to != address(0), "Gecersiz alici");
        require(_balances[from] >= value, "Yetersiz bakiye");
        require(_allowances[from][msg.sender] >= value, "Yetersiz limit");

        _allowances[from][msg.sender] -= value;
        _balances[from] -= value;
        _balances[to] += value;
        emit Transfer(from, to, value);
        return true;
    }

    // Test yardimcisi: Token basma (mint)
    function mint(address to, uint256 value) external {
        _totalSupply += value;
        _balances[to] += value;
        emit Transfer(address(0), to, value);
    }
}
