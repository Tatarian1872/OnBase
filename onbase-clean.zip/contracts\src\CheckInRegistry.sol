// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import { IEAS, AttestationRequest, AttestationRequestData } from "./interfaces/IEAS.sol";
import { IERC20 } from "./interfaces/IERC20.sol";

/**
 * @title CheckInRegistry
 * @dev Kullanıcıların fiziksel mekanlara check-in yapmasını, USDC ile ödeme almasını,
 * GPS koordinatlarının doğruluğunu validator imzasıyla teyit etmesini ve
 * EAS (Ethereum Attestation Service) üzerinde on-chain kanıt (attestation) oluşturmasını sağlar.
 */
contract CheckInRegistry {
    // --- Yapılar (Structs) ---
    
    struct CheckIn {
        bytes32 venueHash;       // Mekanın kimlik hash'i
        uint64 timestamp;        // Check-in yapılan zaman
        uint64 expiry;           // Check-in son geçerlilik zamanı
        bytes32 attestationUid;  // EAS attestation UID'si
    }

    // --- Durum Değişkenleri (State Variables) ---
    
    address public owner;
    IERC20 public immutable usdcToken;
    IEAS public immutable eas;
    bytes32 public easSchema;
    
    address public trustedValidator; // GPS doğruluğunu imzalayan sunucu adresi
    uint256 public checkInFee;       // USDC cinsinden check-in ücreti (6 decimal)
    
    // Kullanıcı adresinden aktif check-in bilgisine eşleme
    mapping(address => CheckIn) public activeCheckIns;
    
    // Reentrancy koruması için
    uint8 private _unlocked = 1;

    // --- Olaylar (Events) ---
    
    event CheckedIn(
        address indexed user,
        bytes32 indexed venueHash,
        uint64 expiry,
        bytes32 attestationUid
    );
    event FeesWithdrawn(address indexed owner, uint256 amount);
    event FeeUpdated(uint256 oldFee, uint256 newFee);
    event ValidatorUpdated(address oldValidator, address newValidator);
    event SchemaUpdated(bytes32 oldSchema, bytes32 newSchema);

    // --- Değiştiriciler (Modifiers) ---
    
    modifier onlyOwner() {
        require(msg.sender == owner, "Yetkisiz: Sadece sahip");
        _;
    }
    
    modifier nonReentrant() {
        require(_unlocked == 1, "Kilitli: Reentrancy tespiti");
        _unlocked = 0;
        _;
        _unlocked = 1;
    }

    // --- Yapıcı (Constructor) ---
    
    constructor(
        address _usdcToken,
        address _eas,
        bytes32 _easSchema,
        address _trustedValidator,
        uint256 _initialFee
    ) {
        require(_usdcToken != address(0), "Gecersiz USDC adresi");
        require(_eas != address(0), "Gecersiz EAS adresi");
        require(_trustedValidator != address(0), "Gecersiz validator adresi");
        
        owner = msg.sender;
        usdcToken = IERC20(_usdcToken);
        eas = IEAS(_eas);
        easSchema = _easSchema;
        trustedValidator = _trustedValidator;
        checkInFee = _initialFee;
    }

    // --- Ana Fonksiyonlar (External Functions) ---

    /**
     * @notice Kullanıcıyı belirli bir mekana check-in yapar.
     * @param venueHash Mekanın kimlik hash'i keccak256(venueId + salt).
     * @param duration Check-in geçerlilik süresi (saniye cinsinden, örn. 10800 saniye = 3 saat).
     * @param sigExpirationTimestamp Validator imzasının son kullanma zamanı (replay koruması için).
     * @param gpsSignature Validator (sunucu) tarafından atılan GPS doğrulama imzası.
     */
    function checkIn(
        bytes32 venueHash,
        uint64 duration,
        uint256 sigExpirationTimestamp,
        bytes calldata gpsSignature
    ) external nonReentrant {
        // 1. Zaman ve süre kontrolleri
        require(duration > 0, "Süre sifirdan buyuk olmalidir");
        require(block.timestamp <= sigExpirationTimestamp, "Validator imzası zaman asimina ugradi");
        
        // 2. GPS İmza Doğrulaması (GPS Spoofing Koruması)
        // İmzalanan mesaj yapısı: [Kullanıcı Adresi, Mekan Hash'i, İmza Son Kullanma Tarihi]
        bytes32 messageHash = keccak256(abi.encodePacked(msg.sender, venueHash, sigExpirationTimestamp));
        bytes32 ethSignedMessageHash = keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", messageHash));
        
        address signer = recoverSigner(ethSignedMessageHash, gpsSignature);
        require(signer == trustedValidator, "Gecersiz GPS imzasi: Yetkisiz validator");
        
        // 3. USDC Ücretinin Tahsil Edilmesi
        if (checkInFee > 0) {
            bool success = usdcToken.transferFrom(msg.sender, address(this), checkInFee);
            require(success, "USDC transferi basarisiz");
        }
        
        // 4. EAS Üzerinde Attestation (Varlık Kanıtı) Oluşturulması
        uint64 checkInExpiry = uint64(block.timestamp + duration);
        bytes32 attestationUid = bytes32(0);
        
        // EAS şeması tanımlı ise zincir üstü kanıt oluştur
        if (easSchema != bytes32(0)) {
            AttestationRequest memory request = AttestationRequest({
                schema: easSchema,
                data: AttestationRequestData({
                    recipient: msg.sender,
                    expirationTime: checkInExpiry,
                    revocable: true,
                    refUID: bytes32(0),
                    data: abi.encode(venueHash, block.timestamp),
                    value: 0
                })
            });
            
            // EAS kontratını çağır
            attestationUid = eas.attest(request);
        }
        
        // 5. Durumun Güncellenmesi (Eski check-in'in üzerine yazılır)
        activeCheckIns[msg.sender] = CheckIn({
            venueHash: venueHash,
            timestamp: uint64(block.timestamp),
            expiry: checkInExpiry,
            attestationUid: attestationUid
        });
        
        emit CheckedIn(msg.sender, venueHash, checkInExpiry, attestationUid);
    }

    // --- Görünüm Fonksiyonları (View Functions) ---

    /**
     * @notice Belirli bir kullanıcının ilgili mekanda aktif check-in'i olup olmadığını sorgular.
     */
    function isCheckInActive(address user, bytes32 venueHash) external view returns (bool) {
        CheckIn memory userCheckIn = activeCheckIns[user];
        return (userCheckIn.venueHash == venueHash && 
                userCheckIn.expiry > block.timestamp && 
                userCheckIn.timestamp <= block.timestamp);
    }

    /**
     * @notice Kullanıcının aktif check-in detaylarını döner.
     */
    function getActiveCheckIn(address user) external view returns (CheckIn memory) {
        CheckIn memory userCheckIn = activeCheckIns[user];
        if (userCheckIn.expiry <= block.timestamp) {
            // Süresi geçmişse boş kayıt döner
            return CheckIn(bytes32(0), 0, 0, bytes32(0));
        }
        return userCheckIn;
    }

    // --- Yönetici Fonksiyonları (Owner Functions) ---

    function setCheckInFee(uint256 newFee) external onlyOwner {
        emit FeeUpdated(checkInFee, newFee);
        checkInFee = newFee;
    }

    function setTrustedValidator(address newValidator) external onlyOwner {
        require(newValidator != address(0), "Gecersiz validator adresi");
        emit ValidatorUpdated(trustedValidator, newValidator);
        trustedValidator = newValidator;
    }

    function setEasSchema(bytes32 newSchema) external onlyOwner {
        emit SchemaUpdated(easSchema, newSchema);
        easSchema = newSchema;
    }

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "Gecersiz yeni sahip");
        owner = newOwner;
    }

    /**
     * @notice Biriken check-in ücretlerini çeker.
     */
    function withdrawFees() external onlyOwner {
        uint256 balance = usdcToken.balanceOf(address(this));
        require(balance > 0, "Cekilecek bakiye yok");
        
        bool success = usdcToken.transfer(owner, balance);
        require(success, "Bakiye cekme basarisiz");
        
        emit FeesWithdrawn(owner, balance);
    }

    // --- Dahili İmza Doğrulama Yardımcıları (Internal Signature Helpers) ---

    function recoverSigner(bytes32 ethSignedMessageHash, bytes memory sig) public pure returns (address) {
        (bytes32 r, bytes32 s, uint8 v) = splitSignature(sig);
        return ecrecover(ethSignedMessageHash, v, r, s);
    }

    function splitSignature(bytes memory sig) public pure returns (bytes32 r, bytes32 s, uint8 v) {
        require(sig.length == 65, "Gecersiz imza uzunlugu");
        assembly {
            // İlk 32 byte veri uzunluğu bilgisini içerir, bu yüzden 32 ekleyerek veriye ulaşılır.
            r := mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
        }
    }
}
